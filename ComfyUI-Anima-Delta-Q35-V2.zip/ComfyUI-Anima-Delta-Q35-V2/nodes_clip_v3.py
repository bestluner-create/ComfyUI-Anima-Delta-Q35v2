"""V3 CLIP jumper: one node loads qwen35_4b in 1.1 and/or 2B format.

Delegates to installed packs, does not ship tokenizer/alignment.
"""

from __future__ import annotations

import logging
import sys

import folder_paths

logger = logging.getLogger(__name__)

FORMATS = ("3.8 1.1 base", "qwen 3.5 strong")

_2B_CLASSES = (
    "LoadQwen35AnimaCLIP",
    "AnimaQwen35CLIPLoader",
    "Qwen35AnimaCLIPLoader",
)


def _qwen35_files():
    def ok(name):
        fn = str(name).replace("\\", "/").rsplit("/", 1)[-1].lower()
        return fn.endswith(".safetensors") and any(
            m in fn for m in ("qwen35_4b", "qwen3.5-4b", "qwen3_5_4b")
        )

    names = sorted({n for n in folder_paths.get_filename_list("text_encoders") if ok(n)})
    pref = "qwen35_4b.safetensors"
    if pref in names:
        names.remove(pref)
        names.insert(0, pref)
    return names or [pref]


def _mapping():
    found = {}
    try:
        import nodes as comfy_nodes
        table = getattr(comfy_nodes, "NODE_CLASS_MAPPINGS", None)
        if isinstance(table, dict):
            found.update(table)
    except Exception:
        pass
    skip = ("transformers", "timm", "torch", "numpy", "PIL")
    for name, mod in list(sys.modules.items()):
        if mod is None or not name:
            continue
        if any(name == s or name.startswith(s + ".") for s in skip):
            continue
        table = getattr(mod, "__dict__", {}).get("NODE_CLASS_MAPPINGS")
        if isinstance(table, dict):
            found.update(table)
    return found


def _call_loader(cls, qwen35_model: str, extra=None):
    inst = cls()
    fn = getattr(inst, "load_clip", None)
    if fn is None:
        func = getattr(cls, "FUNCTION", "load_clip")
        fn = getattr(inst, func)
    extra = dict(extra or {})
    attempts = [
        {"qwen35_model": qwen35_model, **extra},
        {"clip_name": qwen35_model, **extra},
        {"qwen35_model": qwen35_model},
        {"clip_name": qwen35_model},
        qwen35_model,
    ]
    last = None
    for args in attempts:
        try:
            out = fn(**args) if isinstance(args, dict) else fn(args)
            break
        except TypeError as exc:
            last = exc
            out = None
    else:
        raise last
    if isinstance(out, tuple):
        return out[0]
    return out


def _load_11(qwen35_model: str):
    cls = _mapping().get("AnimaQwen35Loader")
    if cls is None:
        raise RuntimeError(
            "V3 CLIP: AnimaQwen35Loader not found. Keep comfyui-anima-3-8B installed."
        )
    return _call_loader(cls, qwen35_model)


def _load_2b(qwen35_model: str):
    table = _mapping()
    for name in _2B_CLASSES:
        cls = table.get(name)
        if cls is not None:
            return _call_loader(cls, qwen35_model, extra={
                "use_calibration": True,
                "use_alignment": True,
                "alignment_strength": 1.0,
                "output_scale": 1.0,
            }), name
    raise RuntimeError(
        "V3 CLIP: 2B loader not found. Install comfyui-qwen35-anima "
        "(CivitAI 2455272) for qwen 3.5 strong."
    )



NATIVE_CAP = 512


def _cap_obj(obj, cap: int):
    """Slice token length only. Do not cut pooled 1024-d vectors."""
    try:
        import torch
    except Exception:
        torch = None
    if torch is not None and hasattr(torch, "is_tensor") and torch.is_tensor(obj):
        is_int = obj.dtype in (
            torch.int8, torch.int16, torch.int32, torch.int64, torch.uint8
        )
        if obj.ndim == 1:
            if is_int and obj.shape[0] > cap:
                return obj[:cap]
            return obj
        if obj.ndim == 2:
            if is_int and obj.shape[1] > cap:
                return obj[:, :cap]
            return obj
        if obj.ndim >= 3 and obj.shape[-2] > cap:
            return obj[..., :cap, :]
        return obj
    if isinstance(obj, dict):
        return {k: _cap_obj(v, cap) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_cap_obj(v, cap) for v in obj]
    if isinstance(obj, tuple):
        return tuple(_cap_obj(v, cap) for v in obj)
    return obj


def _wrap_fn(fn, cap: int):
    if fn is None:
        return fn
    raw = fn
    while getattr(raw, "_q35v3_raw", None) is not None:
        raw = raw._q35v3_raw

    def wrapped(*args, **kwargs):
        for key in ("max_length", "max_tokens"):
            if key in kwargs and kwargs[key] is not None:
                try:
                    kwargs[key] = min(int(kwargs[key]), cap)
                except Exception:
                    pass
        args = tuple(_cap_obj(a, cap) for a in args)
        kwargs = {k: _cap_obj(v, cap) for k, v in kwargs.items()}
        return _cap_obj(raw(*args, **kwargs), cap)

    wrapped._q35v3_capped = True
    wrapped._q35v3_raw = raw
    wrapped._q35v3_cap = cap
    return wrapped


def _patch_clip_inplace(clip, cap: int = NATIVE_CAP):
    if clip is None:
        return clip
    names = (
        "tokenize",
        "tokenize_with_weights",
        "encode",
        "encode_from_tokens",
        "encode_from_tokens_scheduled",
        "encode_token_weights",
    )
    for name in names:
        fn = getattr(clip, name, None)
        if callable(fn):
            setattr(clip, name, _wrap_fn(fn, cap))
    for attr in ("cond_stage_model", "model", "transformer"):
        sub = getattr(clip, attr, None)
        if sub is None:
            continue
        for name in ("encode", "forward", "encode_token_weights"):
            fn = getattr(sub, name, None)
            if callable(fn):
                try:
                    setattr(sub, name, _wrap_fn(fn, cap))
                except Exception:
                    pass
    try:
        clip._q35v3_cap = cap
    except Exception:
        pass
    return clip


def _tag(clip, fmt: str, role: str):
    if clip is None:
        return None
    try:
        clip.anima_v3_format = fmt
        clip.anima_v3_role = role
    except Exception:
        pass
    return clip


class AnimaQ35V2ClipLoader:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "qwen35_model": (_qwen35_files(),),
                "clip_format": (list(FORMATS), {"default": "3.8 1.1 base"}),
            },
            "optional": {
                "native_06b": ("CLIP",),
            },
        }

    RETURN_TYPES = ("CLIP", "CLIP", "STRING")
    RETURN_NAMES = ("native_clip", "qwen35_clip", "log")
    FUNCTION = "load"
    CATEGORY = "Anima Delta Mix / Q35 V2"
    DESCRIPTION = (
        "Loads qwen35_4b. pair_11: native=0.6B in, qwen=1.1 2560. "
        "q4b_dir: 0.6B stays, 4B@1024 is conductor. No 2560."
    )

    def load(self, qwen35_model, clip_format, native_06b=None):
        clip_format = {
            "pair_11": "3.8 1.1 base",
            "2b_as_native": "qwen 3.5 strong",
            "q4b_dir": "qwen 3.5 strong",
        }.get(clip_format, clip_format)
        if clip_format == "3.8 1.1 base":
            if native_06b is None:
                raise RuntimeError(
                    "Q35 V2 3.8 1.1 base needs native_06b (CLIPLoader qwen_3_06b_base)."
                )
            qwen_11 = _tag(_load_11(qwen35_model), clip_format, "qwen35_2560")
            native = _tag(native_06b, clip_format, "native_06b")
            log = f"Q35 V2 CLIP 3.8 1.1 base file={qwen35_model} native=0.6B qwen=1.1_2560"
            logger.info(log)
            return (native, qwen_11, log)

        if native_06b is None:
            raise RuntimeError(
                "Q35 V2 qwen 3.5 strong needs native_06b. 4B is conductor, 0.6B stays."
            )
        clip_4b, src = _load_2b(qwen35_model)
        clip_4b = _patch_clip_inplace(clip_4b, NATIVE_CAP)
        native = _tag(native_06b, "qwen 3.5 strong", "native_06b")
        qwen_out = _tag(clip_4b, "qwen 3.5 strong", "conductor_2b")
        log = (
            f"Q35 V2 CLIP qwen 3.5 strong file={qwen35_model} "
            f"native=0.6B conductor={src} cap={NATIVE_CAP} no_2560"
        )
        logger.info(log)
        return (native, qwen_out, log)


class AnimaQ35V2ClipPair:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "native_clip": ("CLIP",),
                "qwen35_clip": ("CLIP",),
                "clip_format": (list(FORMATS), {"default": "3.8 1.1 base"}),
            }
        }

    RETURN_TYPES = ("CLIP", "CLIP", "STRING")
    RETURN_NAMES = ("native_clip", "qwen35_clip", "log")
    FUNCTION = "route"
    CATEGORY = "Anima Delta Mix / Q35 V2"
    DESCRIPTION = "Passthrough only. Use DeltaMix Q35 CLIP Loader V3."

    def route(self, native_clip, qwen35_clip, clip_format):
        log = (
            f"V3 CLIP Pair passthrough format={clip_format} "
            "(does not load weights; use CLIP Loader V3)"
        )
        logger.info(log)
        return (
            _tag(native_clip, clip_format, "native_passthrough"),
            _tag(qwen35_clip, clip_format, "qwen_passthrough"),
            log,
        )
