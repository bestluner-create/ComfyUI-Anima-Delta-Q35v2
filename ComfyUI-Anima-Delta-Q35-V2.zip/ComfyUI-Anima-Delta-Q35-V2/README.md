# Anima Delta Mix — Q35 V2

Attach path is full only. `stem` / `g1g2` are not on the node. CLIP format is the remaining switch.

## Nodes

- DeltaMix Q35 CLIP Loader V2
- DeltaMix Q35 Prompt V2
- DeltaMix Q35 Attach V2
- Prompt Text Delta
- Prompt Dual Delta

## Known problems

Switching `3.8 1.1 base` and `qwen 3.5 strong` on one live load can smear the next frame. The problem is known. Part of it cannot be fixed in this node without breaking the path.

If the frame smears: change the loaded model, then load the checkpoint again, then set the format you want. Do not keep switching base / strong on the same load.

## CLIP formats

- `3.8 1.1 base` — native 0.6B + official 2560 connector path. Same picture as the earlier Q35 graph.
- `qwen 3.5 strong` — native 0.6B stays, Qwen 3.5 4B is the leading CLIP. No 2560 sidecar.

Base still needs `comfyui-anima-3-8B`. Strong still needs `comfyui-qwen35-anima`.
