from .nodes_attach_v3 import AnimaQ35V2Attach
from .nodes_clip_v3 import AnimaQ35V2ClipLoader
from .nodes_prompt_v3 import AnimaQ35V2Prompt
from .nodes_text import PromptDualDelta, PromptTextDelta

NODE_CLASS_MAPPINGS = {
    "AnimaQ35V2Attach": AnimaQ35V2Attach,
    "AnimaQ35V2ClipLoader": AnimaQ35V2ClipLoader,
    "AnimaQ35V2Prompt": AnimaQ35V2Prompt,
    "PromptTextDelta": PromptTextDelta,
    "PromptDualDelta": PromptDualDelta,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "AnimaQ35V2Attach": "DeltaMix Q35 Attach V2",
    "AnimaQ35V2ClipLoader": "DeltaMix Q35 CLIP Loader V2",
    "AnimaQ35V2Prompt": "DeltaMix Q35 Prompt V2",
    "PromptTextDelta": "Prompt Text Delta",
    "PromptDualDelta": "Prompt Dual Delta",
}

__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS"]
