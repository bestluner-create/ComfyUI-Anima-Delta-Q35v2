"""Q35 V2 Attach. Dest mask from locked V2 plus 512/1024 bank detect.

Does not replace AnimaQ35Attach or AnimaQ35AttachV2.
"""

from __future__ import annotations

import logging
import os

import torch
import torch.nn.functional as F

from safetensors import SafetensorError, safe_open

import comfy.model_management
import comfy.ops
import comfy.utils
import folder_paths

from .official_bridge import official_modules

logger = logging.getLogger(__name__)

PREFIX = "net.anima_v2_connector."

STEM_52 = (
    0, 1, 4, 5, 8, 9, 12, 13, 16, 17, 20, 21, 24, 25, 26,
    29, 30, 33, 34, 37, 38, 41, 42, 45, 46, 49, 50, 51,
)
G1_52 = (2, 6, 10, 14, 18, 22, 28, 32, 36, 40, 44, 48)
G2_52 = (3, 7, 11, 15, 19, 23, 27, 31, 35, 39, 43, 47)
WATCH_52 = (7, 15, 23, 31)
G1G2_52 = tuple(sorted(G1_52 + G2_52))

PUBLIC_MODES = ("full",)
READ_MODES = ("full",)
DEST_MODES = {"g1g2", "stem", "g2"}
_MODE_ALIAS = {"g1g2_guard": "g1g2", "stem_guard": "stem"}
BANK_MODES = ("auto", "512", "1024")
BANK_CAP = 1024
BANK_STOCK = 512
BAKED_STRENGTH = 0.50
BAKED_CAP = 0.50
HEAD_LOCK = frozenset((0, 1))
EXCLUDE_IDS = frozenset((
    1424, 6078, 10661, 14317, 19225, 14105, 24050, 56849, 32452, 74718,
    39802, 24676, 33377, 9963, 18739, 21633, 39843, 30995, 71048, 32171,
    85778, 5334, 7541, 30216, 44613, 99034,
))


def _connector_files():
    out = []
    for name in folder_paths.get_filename_list("diffusion_models"):
        if not name.lower().endswith(".safetensors"):
            continue
        path = folder_paths.get_full_path("diffusion_models", name)
        if not path or not os.path.isfile(path):
            continue
        try:
            with safe_open(path, framework="pt", device="cpu") as f:
                keys = f.keys()
                meta = f.metadata() or {}
        except (OSError, ValueError, SafetensorError):
            continue
        if meta.get("architecture") == "anima_v2_connector_sidecar":
            out.append(name)
        elif any(k.startswith(PREFIX) or "anima_v2_connector." in k for k in keys):
            out.append(name)
    return sorted(out) or ["anima_v2_connector_only.safetensors"]


def _connector_state(path: str) -> tuple[dict, dict]:
    state, metadata = comfy.utils.load_torch_file(path, return_metadata=True)
    metadata = metadata or {}
    prefix = metadata.get("anima_v2_connector_prefix", PREFIX)
    conn = {}
    for name, tensor in state.items():
        if name.startswith(prefix):
            conn[name[len(prefix):]] = tensor
        elif "anima_v2_connector." in name:
            conn[name.split("anima_v2_connector.", 1)[-1]] = tensor
    if not conn:
        raise RuntimeError(f"No connector tensors in {path}")
    return conn, metadata


def _dit_blocks(dit):
    blocks = getattr(dit, "blocks", None)
    if blocks is None:
        blocks = getattr(dit, "transformer_blocks", None)
    if blocks is None:
        raise RuntimeError("DiT has no blocks / transformer_blocks.")
    return list(blocks)


def _current_context(args, kwargs):
    ctx = kwargs.get("context")
    if ctx is not None and getattr(ctx, "ndim", 0) == 3:
        return ctx
    if len(args) >= 3 and getattr(args[2], "ndim", 0) == 3:
        return args[2]
    if len(args) >= 2 and getattr(args[1], "ndim", 0) == 3:
        return args[1]
    return None


def _align_bank(bank, ref):
    if ref is None or bank is None:
        return bank
    if bank.device != ref.device:
        bank = bank.to(device=ref.device)
    if bank.dtype != ref.dtype:
        bank = bank.to(dtype=ref.dtype)
    if bank.shape[0] != ref.shape[0]:
        if bank.shape[0] == 1:
            bank = bank.expand(ref.shape[0], -1, -1)
        elif ref.shape[0] == 1:
            bank = bank[:1]
        else:
            return None
    if bank.shape[-1] != ref.shape[-1]:
        return None
    if bank.shape[1] != ref.shape[1]:
        if bank.shape[1] > ref.shape[1]:
            bank = bank[:, : ref.shape[1]]
        else:
            bank = F.pad(bank, (0, 0, 0, ref.shape[1] - bank.shape[1]))
    return bank


def _swap_context(args, kwargs, new_ctx):
    ref = _current_context(args, kwargs)
    new_ctx = _align_bank(new_ctx, ref)
    if new_ctx is None:
        return args, kwargs, False
    if "context" in kwargs and kwargs["context"] is not None:
        kwargs = dict(kwargs)
        kwargs["context"] = new_ctx
        return args, kwargs, True
    args = list(args)
    if len(args) >= 3 and getattr(args[2], "ndim", 0) == 3:
        args[2] = new_ctx
        return tuple(args), kwargs, True
    if len(args) >= 2 and getattr(args[1], "ndim", 0) == 3:
        args[1] = new_ctx
        return tuple(args), kwargs, True
    return tuple(args), kwargs, False


def _zero_excluded(delta, ids):
    if ids is None or not EXCLUDE_IDS:
        return delta
    try:
        id_t = ids
        if not torch.is_tensor(id_t):
            return delta
        if id_t.ndim == 1:
            id_t = id_t.unsqueeze(0)
        if id_t.shape[1] != delta.shape[1]:
            if id_t.shape[1] > delta.shape[1]:
                id_t = id_t[:, : delta.shape[1]]
            else:
                return delta
        excl = torch.tensor(sorted(EXCLUDE_IDS), device=id_t.device, dtype=id_t.dtype)
        hit = (id_t.unsqueeze(-1) == excl).any(-1)
        keep = (~hit).to(dtype=delta.dtype).unsqueeze(-1)
        return delta * keep
    except Exception:
        return delta


def _mix_bank(native, expanded, *, strength: float, cap: float | None, ids=None):
    """Q4B-shaped mix. ids: 0.6B token ids, excluded slots stay native."""
    native = _align_bank(native, expanded)
    if native is None or expanded is None:
        return None
    delta = expanded - native
    delta = _zero_excluded(delta, ids)
    if cap is not None:
        # Per-token cap: ||D|| <= cap * ||native||
        eps = torch.finfo(delta.dtype).eps
        n_norm = native.float().norm(dim=-1, keepdim=True).clamp_min(eps)
        d_norm = delta.float().norm(dim=-1, keepdim=True).clamp_min(eps)
        scale = (float(cap) * n_norm / d_norm).clamp(max=1.0).to(dtype=delta.dtype)
        delta = delta * scale
    return native + float(strength) * delta


def _target_bank(dit, ids_len: int, adapter_len: int) -> int:
    mode = getattr(dit, "_q35v3_bank_mode", "auto")
    if mode == "512":
        return BANK_STOCK
    if mode == "1024":
        return BANK_CAP
    # auto: stock 512 unless ids or adapter already ran longer
    seen = max(int(ids_len), int(adapter_len))
    if seen <= BANK_STOCK:
        return BANK_STOCK
    return min(BANK_CAP, max(BANK_STOCK, seen))


def _fit_len(bank, length: int):
    if bank.shape[1] > length:
        return bank[:, :length]
    if bank.shape[1] < length:
        return F.pad(bank, (0, 0, 0, length - bank.shape[1]))
    return bank


def _native_bank(dit, source, kwargs):
    adapter = getattr(dit, "llm_adapter", None)
    target_ids = kwargs.get("t5xxl_ids")
    if adapter is None or source is None or target_ids is None:
        return None
    try:
        dtype = adapter.embed.weight.dtype
        src = source.to(dtype=dtype)
        ids = target_ids.to(device=src.device, dtype=torch.long)
        if ids.ndim == 1:
            ids = ids.unsqueeze(0)
        if src.ndim == 2:
            src = src.unsqueeze(0)
        bank = adapter(src, ids)
        target = _target_bank(dit, ids.shape[1], bank.shape[1])
        dit._q35v3_bank_seen = int(bank.shape[1])
        dit._q35v3_bank_ids = int(ids.shape[1])
        dit._q35v3_bank_target = int(target)
        return _fit_len(bank, target).to(dtype=source.dtype)
    except Exception as exc:
        logger.warning("Attach V3 native bank failed: %s", exc)
        return None


def _install_read_policy(dit, mode: str, dest: tuple[int, ...], bank_mode: str) -> str:
    dest_set = set(dest)
    dit._q35v2_mode = mode
    dit._q35v2_dest = dest_set
    dit._q35v3_bank_mode = bank_mode
    dit._q35v2_native_ctx = None
    dit._q35v2_swap_ok = 0
    dit._q35v2_swap_skip = 0
    dit._q35v3_q4b_logged = False
    dit._q35v3_te_logged = False
    dit._q35v3_q4b_buf = []
    dit._q35v2_raw06_buf = []

    if getattr(dit, "_q35v3_wrapped", False):
        rail = "auto_q4b_guard"
        return (
            f"read={mode} dest={len(dest_set)} rail={rail} "
            f"bank={bank_mode} patched_forward=slot reuse"
        )

    blocks = _dit_blocks(dit)
    n_blocks = len(blocks)
    if n_blocks != 52:
        logger.warning("Attach V2 expected 52 DiT blocks, got %s", n_blocks)

    for idx, block in enumerate(blocks):
        orig = block.forward

        def _block_fwd(*args, _orig=orig, _idx=idx, **kwargs):
            mode_now = getattr(dit, "_q35v2_mode", "full")
            dest_now = set(getattr(dit, "_q35v2_dest", set()))
            q4b_on = bool(getattr(dit, "_q35v3_q4b", False))
            if q4b_on:
                dest_now -= HEAD_LOCK
            native = getattr(dit, "_q35v2_native_ctx", None)
            q4b_ctx = getattr(dit, "_q35v3_q4b_ctx", None)
            use_native = native is not None and (
                mode_now == "native" or _idx not in dest_now
            )
            if use_native:
                args, kwargs, ok = _swap_context(args, kwargs, native)
            elif q4b_ctx is not None and native is not None and _idx in dest_now:
                mixed = _mix_bank(
                    native, q4b_ctx, strength=BAKED_STRENGTH, cap=BAKED_CAP
                )
                args, kwargs, ok = _swap_context(args, kwargs, mixed)
            else:
                ok = None
            if ok is True:
                dit._q35v2_swap_ok = getattr(dit, "_q35v2_swap_ok", 0) + 1
            elif ok is False:
                dit._q35v2_swap_skip = getattr(dit, "_q35v2_swap_skip", 0) + 1
            return _orig(*args, **kwargs)

        block.forward = _block_fwd

    inner = dit.forward

    def _dit_fwd(x, timesteps, context, **kwargs):
        dit._q35v2_native_ctx = None
        dit._q35v3_q4b_ctx = None
        mode_now = getattr(dit, "_q35v2_mode", "full")
        q4b = bool(getattr(dit, "_q35v3_q4b", False))
        if q4b and mode_now in ("g1g2", "g2"):
            # extra_conds already ran llm_adapter on 0.6B. Do not adapt again.
            dit._q35v2_native_ctx = context
            buf = list(getattr(dit, "_q35v3_q4b_buf", None) or [])
            dit._q35v3_q4b_buf = []
            banks = []
            shapes = []
            for src, ids in buf:
                kw = dict(kwargs)
                if ids is not None:
                    kw["t5xxl_ids"] = ids
                bank = _native_bank(dit, src, kw) if src is not None else None
                shapes.append(None if src is None else tuple(src.shape))
                if bank is not None:
                    banks.append(bank)
            if len(banks) == 1:
                dit._q35v3_q4b_ctx = banks[0]
            elif len(banks) >= 2:
                try:
                    dit._q35v3_q4b_ctx = torch.cat(banks, dim=0)
                except Exception:
                    dit._q35v3_q4b_ctx = banks[0]
            else:
                src = getattr(dit, "_q35v3_q4b_src", None)
                ids = getattr(dit, "_q35v3_q4b_ids", None)
                kw = dict(kwargs)
                if ids is not None:
                    kw["t5xxl_ids"] = ids
                dit._q35v3_q4b_ctx = _native_bank(dit, src, kw) if src is not None else None
            if not getattr(dit, "_q35v3_q4b_logged", False):
                dit._q35v3_q4b_logged = True
                ctx4 = dit._q35v3_q4b_ctx
                logger.info(
                    "q4b mix 06bank=%s src4=%s bank4=%s nbuf=%s mode=%s",
                    None if context is None else tuple(context.shape),
                    shapes,
                    None if ctx4 is None else tuple(ctx4.shape),
                    len(buf),
                    mode_now,
                )
        elif (not q4b) and mode_now != "full":
            buf06 = list(getattr(dit, "_q35v2_raw06_buf", None) or [])
            dit._q35v2_raw06_buf = []
            banks = []
            for raw06, ids06 in buf06:
                kw = dict(kwargs)
                if ids06 is not None:
                    kw["t5xxl_ids"] = ids06
                bank = _native_bank(dit, raw06, kw) if raw06 is not None else None
                if bank is not None:
                    banks.append(bank)
            if len(banks) >= 2:
                try:
                    dit._q35v2_native_ctx = torch.cat(banks, dim=0)
                except Exception:
                    dit._q35v2_native_ctx = banks[0]
            elif len(banks) == 1:
                dit._q35v2_native_ctx = banks[0]
            # Never _native_bank(context): context is already connector-expanded.
        try:
            return inner(x, timesteps, context, **kwargs)
        finally:
            dit._q35v2_native_ctx = None
            dit._q35v3_q4b_ctx = None

    dit.forward = _dit_fwd
    dit._q35v3_wrapped = True
    return (
        f"read={mode} dest={len(dest_set)} rail=auto_q4b_guard "
        f"bank={bank_mode} patched_forward=slot blocks={n_blocks}"
    )


def _norm_mode(mode: str) -> str:
    return _MODE_ALIAS.get(mode, mode)


def _dest_for_mode(mode: str) -> tuple[int, ...]:
    mode = _norm_mode(mode)
    if mode == "full":
        return tuple(range(52))
    if mode == "g1g2":
        return G1G2_52
    if mode == "stem":
        return STEM_52
    if mode == "g2":
        return G2_52
    if mode == "native":
        return ()
    raise ValueError(mode)


class AnimaQ35V2Attach:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model": ("MODEL",),
                "connector": (_connector_files(),),
            }
        }

    RETURN_TYPES = ("MODEL", "STRING")
    RETURN_NAMES = ("model", "log")
    FUNCTION = "attach"
    CATEGORY = "Anima Delta Mix / Q35 V2"
    DESCRIPTION = (
        "UNSTABLE across a CLIP format switch on one live load. "
        "Path is full only. Sector split is not in this build."
    )

    def attach(self, model, connector, read_mode="full", bank_mode="auto"):
        # Widget hidden. Old graphs may still pass read_mode; only full is live.
        read_mode = "full"
        bank_mode = "auto"
        if read_mode not in READ_MODES:
            raise ValueError(f"read_mode must be one of {READ_MODES}")
        if bank_mode not in BANK_MODES:
            raise ValueError(f"bank_mode must be one of {BANK_MODES}")

        off = official_modules()
        path = folder_paths.get_full_path("diffusion_models", connector)
        if path is None or not os.path.isfile(path):
            raise FileNotFoundError(connector)

        cloned = model.clone()
        base = cloned.model
        dit = getattr(base, "diffusion_model", None)
        native = getattr(dit, "llm_adapter", None)
        if native is None or len(getattr(native, "blocks", [])) != 6:
            raise RuntimeError("MODEL is not Anima 3.8 (llm_adapter / 6 blocks missing).")

        conn_state, metadata = _connector_state(path)
        ops = base.model_config.custom_operations
        if ops is None:
            ops = comfy.ops.pick_operations(
                base.get_dtype(),
                base.manual_cast_dtype,
                fp8_optimizations=base.model_config.optimizations.get("fp8", False),
                model_config=base.model_config,
            )

        cfg = {
            "num_queries": 64,
            "resampler_blocks": 6,
            "resampler_dim": 2048,
            "resampler_heads": 16,
            "mlp_hidden_dim": 5632,
            "initialize_from_native": False,
            "register_native_adapter": False,
            "initialize_resampler": False,
        }
        adapter_meta = {
            k[len("anima_v2_adapter_"):]: v
            for k, v in metadata.items()
            if k.startswith("anima_v2_adapter_")
        }
        if adapter_meta:
            mapping = {
                "semantic_query_tokens": "num_queries",
                "semantic_resampler_blocks": "resampler_blocks",
                "semantic_resampler_dim": "resampler_dim",
                "semantic_resampler_heads": "resampler_heads",
                "semantic_resampler_mlp_hidden_dim": "mlp_hidden_dim",
            }
            for src, dst in mapping.items():
                if src in adapter_meta:
                    cfg[dst] = int(adapter_meta[src])

        connector_mod = off["connector_cls"](
            native_adapter=native,
            semantic_source_dim=2560,
            layer_indices=off["layer_indices"],
            operations=ops,
            **cfg,
        )
        connector_mod.load_trainable_state_dict(conn_state, assign=cloned.is_dynamic())
        connector_mod.eval().requires_grad_(False)
        connector_mod._anima_v2_model_managed = True
        connector_mod._anima_v2_bundle_path = path
        dit.add_module("anima_v2_connector", connector_mod)
        comfy.model_management.archive_model_dtypes(connector_mod)

        orig_ec = base.extra_conds

        def extra_conds(_self, **kwargs):
            src = kwargs.get("anima_q4b_src")
            ids = kwargs.get("anima_q4b_ids")
            src06 = kwargs.get("anima_06_src")
            ids06 = kwargs.get("anima_06_ids")
            dm = getattr(_self, "diffusion_model", None)
            mode_now = getattr(dm, "_q35v2_mode", "full") if dm is not None else "full"
            if dm is not None:
                dm._q35v3_q4b = src is not None
                if src is None:
                    dm._q35v3_q4b_src = None
                    dm._q35v3_q4b_ids = None
                    dm._q35v3_q4b_buf = []
                if src06 is not None:
                    buf06 = getattr(dm, "_q35v2_raw06_buf", None)
                    if buf06 is None:
                        buf06 = []
                        dm._q35v2_raw06_buf = buf06
                    buf06.append((src06, ids06))
                    dm._q35v2_raw06 = src06
                    dm._q35v2_raw06_ids = ids06
                else:
                    dm._q35v2_raw06 = None
                    dm._q35v2_raw06_ids = None
            if src is not None and dm is not None:
                buf = getattr(dm, "_q35v3_q4b_buf", None)
                if buf is None:
                    buf = []
                    dm._q35v3_q4b_buf = buf
                buf.append((src, ids))
                dm._q35v3_q4b_src = src
                dm._q35v3_q4b_ids = ids
                if mode_now in ("full", "stem"):
                    te_key = None
                    te = None
                    for key, val in kwargs.items():
                        if (
                            torch.is_tensor(val)
                            and val.ndim == 3
                            and val.shape[-1] == 1024
                            and key not in ("anima_q4b_src",)
                        ):
                            te_key, te = key, val
                            if key in ("c_crossattn", "cross_attn", "crossattn"):
                                break
                    if te is not None and te_key is not None:
                        aligned = _align_bank(src, te)
                        ids06 = kwargs.get("t5xxl_ids")
                        mixed = _mix_bank(
                            te,
                            aligned,
                            strength=BAKED_STRENGTH,
                            cap=BAKED_CAP,
                            ids=ids06,
                        )
                        if mixed is not None:
                            kwargs[te_key] = mixed
                            if not getattr(dm, "_q35v3_te_logged", False):
                                dm._q35v3_te_logged = True
                                logger.info(
                                    "q4b TE-mix key=%s te=%s src=%s mixed=%s s=0.5 cap=0.5 excl=%s mode=%s",
                                    te_key,
                                    tuple(te.shape),
                                    tuple(src.shape),
                                    tuple(mixed.shape),
                                    len(EXCLUDE_IDS),
                                    mode_now,
                                )
            return orig_ec(**kwargs)

        import types
        base.extra_conds = types.MethodType(extra_conds, base)

        dest = _dest_for_mode(read_mode)
        policy = _install_read_policy(dit, read_mode, dest, bank_mode)
        log = (
            f"Q35 V2 Attach {os.path.basename(path)} tensors={len(conn_state)} "
            f"watch_src={list(off['layer_indices'])} {policy} "
            f"dest_idx={list(dest) if read_mode in DEST_MODES else '-'}"
        )
        logger.info(log)
        return (cloned, log)
