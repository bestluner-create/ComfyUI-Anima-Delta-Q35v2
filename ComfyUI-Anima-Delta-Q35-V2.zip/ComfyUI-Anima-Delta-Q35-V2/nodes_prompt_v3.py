"""Prompt V3.

pair_11 — official emit (1.1 connector).
q4b_dir — 0.6B cond + stash 4B hidden on DiT for Attach mix. No connector.
"""

from __future__ import annotations

import logging
import sys

import comfy.model_management

from .nodes_clip_v3 import _patch_clip_inplace
from .official_bridge import official_modules

logger = logging.getLogger(__name__)


def _seq_len(obj) -> int:
    try:
        import torch
    except Exception:
        torch = None
    if torch is not None and hasattr(torch, "is_tensor") and torch.is_tensor(obj):
        if obj.ndim <= 1:
            return int(obj.shape[0]) if obj.ndim == 1 else 1
        return int(obj.shape[1])
    if isinstance(obj, dict):
        for key in ("input_ids", "tokens", "l", "t5xxl_ids", "ids"):
            if key in obj:
                return _seq_len(obj[key])
        return 0
    if isinstance(obj, (list, tuple)):
        return len(obj[0]) if obj and isinstance(obj[0], (list, tuple)) else len(obj)
    return 0


def _as_ids_tensor(tokens):
    try:
        import torch
    except Exception:
        torch = None

    def from_pairs(seq):
        if not seq:
            return None
        flat = seq
        if isinstance(seq[0], (list, tuple)) and seq[0] and isinstance(seq[0][0], (list, tuple)):
            flat = seq[0]
        ids = []
        for item in flat:
            if isinstance(item, (list, tuple)):
                ids.append(int(item[0]))
            else:
                try:
                    ids.append(int(item))
                except Exception:
                    return None
        if not ids or torch is None:
            return None
        return torch.tensor(ids, dtype=torch.long).unsqueeze(0)

    if torch is not None and hasattr(torch, "is_tensor") and torch.is_tensor(tokens):
        return tokens
    if isinstance(tokens, dict):
        for key in ("input_ids", "t5xxl_ids", "ids", "tokens", "l", "g", "word_ids"):
            if key not in tokens:
                continue
            val = tokens[key]
            if torch is not None and hasattr(torch, "is_tensor") and torch.is_tensor(val):
                return val
            if isinstance(val, (list, tuple)):
                got = from_pairs(list(val))
                if got is not None:
                    return got
        return None
    if isinstance(tokens, (list, tuple)):
        return from_pairs(list(tokens))
    return None


def _ids_from_hidden(hidden):
    try:
        import torch
    except Exception:
        return None
    if hidden is None or not hasattr(hidden, "shape") or len(hidden.shape) < 2:
        return None
    tlen = int(hidden.shape[1])
    return torch.arange(tlen, device=hidden.device, dtype=torch.long).unsqueeze(0)


def _clip_cond(clip, text):
    """Same path as stock CLIPTextEncode."""
    tokens = clip.tokenize(text)
    sched = getattr(clip, "encode_from_tokens_scheduled", None)
    if callable(sched):
        cond = sched(tokens)
        hidden = cond[0][0] if cond else None
        extra = cond[0][1] if cond and len(cond[0]) > 1 else {}
        ids = None
        if isinstance(extra, dict):
            ids = extra.get("t5xxl_ids")
        if ids is None:
            ids = _as_ids_tensor(tokens) or _ids_from_hidden(hidden)
        return cond, hidden, ids
    hidden, pooled, ids = _clip_encode(clip, text)
    if ids is None:
        ids = _ids_from_hidden(hidden)
    return _to_cond(hidden, pooled, ids), hidden, ids


def _clip_encode(clip, text):
    tokens = clip.tokenize(text)
    ids = _as_ids_tensor(tokens)
    enc = getattr(clip, "encode_from_tokens", None)
    hidden = None
    pooled = None
    if callable(enc):
        try:
            out = enc(tokens, return_pooled=True)
        except TypeError:
            out = enc(tokens)
        if isinstance(out, tuple):
            hidden = out[0]
            pooled = out[1] if len(out) > 1 else None
        else:
            hidden = out
    if hidden is None:
        hidden = clip.encode(text)
        if isinstance(hidden, tuple):
            hidden, pooled = hidden[0], hidden[1] if len(hidden) > 1 else None
    return hidden, pooled, ids


def _to_cond(hidden, pooled, ids):
    extra = {}
    if pooled is not None and not isinstance(pooled, dict):
        extra["pooled_output"] = pooled
    try:
        import torch
        if ids is not None and hasattr(torch, "is_tensor") and torch.is_tensor(ids):
            extra["t5xxl_ids"] = ids
            extra["t5xxl_weights"] = torch.ones_like(ids, dtype=torch.float32)
    except Exception:
        pass
    return [[hidden, extra]]


def _dit(model):
    base = getattr(model, "model", model)
    return getattr(base, "diffusion_model", None)


def _is_q4b_clip(clip) -> bool:
    role = getattr(clip, "anima_v3_role", "")
    fmt = getattr(clip, "anima_v3_format", "")
    return role == "conductor_2b" or fmt in ("qwen 3.5 strong", "q4b_dir")


def _unload_clip(clip) -> None:
    try:
        comfy.model_management.unload_model_and_clones(
            clip.patcher,
            unload_additional_models=False,
            all_devices=True,
        )
    except Exception:
        pass


def _emit_11(model, native_clip, qwen35_clip, prompt):
    off = official_modules()
    Prompt = off["prompt"].AnimaQwen35UnifiedPrompt
    emit = off["runtime"].emit_conditioning
    v2_arch = getattr(off["prompt"], "V2_ARCHITECTURE", None)
    if v2_arch is None:
        v2_arch = "anima_qwen35_quality_anchored_semantic_connector_v2"
    try:
        native = Prompt._encode_native(native_clip, prompt)
    finally:
        _unload_clip(native_clip)
    native_source, native_metadata = native[0]
    if native_source.ndim != 3 or native_source.shape[-1] != 1024:
        raise RuntimeError("native_clip must be Qwen3 0.6B.")
    if native_metadata.get("t5xxl_ids") is None:
        raise RuntimeError("Native conditioning has no T5 token IDs.")
    try:
        semantic_states, semantic_mask = Prompt._encode_semantic_layers(
            qwen35_clip, prompt
        )
    finally:
        _unload_clip(qwen35_clip)
    dit = getattr(model.model, "diffusion_model", None)
    native_adapter = getattr(dit, "llm_adapter", None)
    connector = getattr(dit, "anima_v2_connector", None)
    if native_adapter is None or connector is None:
        raise RuntimeError("MODEL has no anima_v2_connector. Run Attach first.")
    path = getattr(connector, "_anima_v2_bundle_path", "q35-attach")
    out = emit(
        expanded_adapter=connector,
        native_adapter=native_adapter,
        native=native,
        native_source=native_source,
        native_metadata=native_metadata,
        semantic_states=semantic_states,
        semantic_mask=semantic_mask,
        adapter_strength=1.0,
        architecture=v2_arch,
        checkpoint_path=path,
    )
    ids06 = native_metadata.get("t5xxl_ids")

    def _stamp(cond):
        if not cond:
            return cond
        stamped = []
        for item in cond:
            hid = item[0]
            extra = dict(item[1]) if len(item) > 1 and isinstance(item[1], dict) else {}
            extra["anima_06_src"] = native_source
            extra["anima_06_ids"] = ids06
            stamped.append([hid, extra])
        return stamped

    if isinstance(out, tuple) and len(out) >= 2:
        return (_stamp(out[0]), _stamp(out[1]))
    if isinstance(out, tuple) and out:
        return (_stamp(out[0]),)
    return _stamp(out)


class AnimaQ35V2Prompt:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model": ("MODEL",),
                "native_clip": ("CLIP",),
                "qwen35_clip": ("CLIP",),
                "prompt": ("STRING", {"multiline": True, "default": ""}),
            }
        }

    RETURN_TYPES = ("CONDITIONING", "CONDITIONING", "STRING")
    RETURN_NAMES = ("expanded", "native", "log")
    FUNCTION = "encode"
    CATEGORY = "Anima Delta Mix / Q35 V2"
    DESCRIPTION = (
        "UNSTABLE. 3.8 1.1 base: official connector emit. "
        "qwen 3.5 strong: 0.6B cond + 4B TE-mix 0.5/0.5."
    )

    def encode(self, model, native_clip, qwen35_clip, prompt):
        if _is_q4b_clip(qwen35_clip):
            cond06, h06, id06 = _clip_cond(native_clip, prompt)
            cond4b, h4b, id4b = _clip_cond(qwen35_clip, prompt)
            if h4b is not None and h06 is not None and hasattr(h4b, "shape") and hasattr(h06, "shape"):
                t06 = int(h06.shape[1])
                if h4b.shape[1] > t06:
                    h4b = h4b[:, :t06]
                    if id4b is not None and hasattr(id4b, "shape") and id4b.shape[-1] > t06:
                        id4b = id4b[..., :t06]
            cond = []
            for item in cond06:
                hid = item[0]
                extra = dict(item[1]) if len(item) > 1 and isinstance(item[1], dict) else {}
                extra["anima_q4b_src"] = h4b
                extra["anima_q4b_ids"] = id4b
                cond.append([hid, extra])
            log = (
                f"Q35 V2 Prompt qwen 3.5 strong 06_len={_seq_len(id06)} "
                f"4b_len={_seq_len(id4b)} 06_ids={type(id06).__name__} "
                f"hid={None if h06 is None else tuple(h06.shape)} "
                f"hid4={None if h4b is None else tuple(getattr(h4b, 'shape', ()))} "
                f"no_connector"
            )
            logger.info(log)
            return (cond, cond, log)

        out = _emit_11(model, native_clip, qwen35_clip, prompt)
        log = "Q35 V2 Prompt 3.8 1.1 base emit=official_bridge"
        logger.info(log)
        if not isinstance(out, tuple):
            return (out, out, log)
        if len(out) >= 2:
            return (out[0], out[1], log)
        return (out[0], out[0], log)
